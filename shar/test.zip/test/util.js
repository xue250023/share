const util = require('util')

async function delay(duration = 1000) {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(duration)
    }, duration)
  })
}

delay(500).then(res => {
  console.log(res)
})


const delayCallback = util.callbackify(delay)

delayCallback(1000, (err, content) => {
  console.log(err)
  console.log(content)
})

const tmp = util.promisify(delayCallback);

tmp(200).then(res => {
  console.log(res)
})



let obj1 = {
  a: 1,
  name: 'lyg',
  children: {
    name: '11',
    age: 19
  }
}
let obj2 = {
  name: 'lyg',
  a: 1,
  children: {
    age: 19,
    name: 11
  }
}

console.log(util.isDeepStrictEqual(obj1, obj2))



