import 'reflect-metadata';


const classDecorator = (target: Object) => {
  console.log('class')
  console.log(target)
  console.log(Reflect.getMetadata('design:paramtypes', target));
};

const propertyDecorator = (target: Object, key: string | symbol) => {
  console.log('prop')
  console.log(target, key)
  console.log(Reflect.getMetadata('design:type', target, key));
  console.log(Reflect.getMetadata('design:paramtypes', target, key));
  console.log(Reflect.getMetadata('design:returntype', target, key));
};

// paramtypes -> [String] 即构造函数接收的参数
// @classDecorator
// class Demo {
//   innerValue: string;
//   constructor(val: string, a: number) {
//     this.innerValue = val;
//   }

//   /*
//    * 元数据的值如下：
//    * type -> String
//    * paramtypes -> undefined
//    * returntype -> undefined
//    */
//   @propertyDecorator
//   demo1: string = 'demo1';

//   /*
//    * 元数据的值如下：
//    * type -> Function
//    * paramtypes -> [String]
//    * returntype -> String
//    */
//   @propertyDecorator
//   demo2(str: string, age: number): string {
//     return str;
//   }
// }
console.log('==========')
// 构造函数类型
type Constructor<T = any> = new (...arg: any[]) => T;

// 类装饰器，用于标识类是需要注入的
const Injectable = () => (target: any) => {
  // console.log('target', target)
};
// console.log()

// 需要注入的类
class InjectService {
  a = 'inject';
  b = 'add'
}

// 被注入的类
@Injectable()
class DemoService {
  constructor(public injectService: InjectService) {}

  test() {
    console.log(this.injectService.a);
  }
}


// 依赖注入函数Factory
const Factory = <T>(target: Constructor<T>): T => {
  console.log(target)
  // 获取target类的构造函数参数providers
  const providers = Reflect.getMetadata('design:paramtypes', target);
  console.log('providers', providers)
  // 将参数依次实例化
  const args = providers.map((provider: Constructor) => new provider());
  console.log('args', args)
  console.log(target)
  // 将实例化的数组作为target类的参数，并返回target的实例
  return new target(...args);
};

Factory(DemoService).test(); // inject