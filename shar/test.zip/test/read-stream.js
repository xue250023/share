const fs = require('fs')
const path = require('path')

const filename = path.resolve(__dirname, './read-stream.txt')

const rs = fs.createReadStream(filename, {
  encoding:'utf-8',
  highWaterMark: 1
})

// console.log(rs)


rs.on('open', () => {
  console.log('hasopen')
})

rs.on('close', () => {
  console.log('close')
})

rs.on('error', (err) => {
  console.log(err)
})

// rs.on('data', chunk => {
//   console.log(chunk)
// })

rs.on('data', chunk => {
  console.log(chunk)
  rs.pause()
  setTimeout(() => {
    rs.resume()
  })
})
rs.on('pause', () => {
  console.log('pause')
})

rs.on('end', () => {
  console.log('end')
})
