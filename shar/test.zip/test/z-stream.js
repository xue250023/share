const fs = require('fs')
const path = require('path')
const os = require('os')
const http = require('http').createServer()



const filename = path.resolve(__dirname, './write-stream-test.txt')

console.log(os.freemem())
async function method1() {
  console.time('method1')
  const fromfile = path.resolve(__dirname, './write-stream.txt');
  const tofile = path.resolve(__dirname, './write-stream22.txt');
  const tmp = await fs.promises.readFile(fromfile);
  await fs.promises.writeFile(tofile, tmp)
  console.timeEnd('method1')
  console.log(os.freemem())
}
method1()

console.log(process.pid)
function method2() {
  console.time('method2')
  console.log(os.freemem())
  const rs = fs.createReadStream('./write-stream.txt');
  const ws = fs.createWriteStream('./write-stream23.txt');
  rs.on('data', (chunk) => {
    flag = ws.write(chunk)
    if(!flag) {
      rs.pause()
    }
  })

  ws.on('drain', () => {
    rs.resume()
  })

  rs.on('end', () => {
    console.log(os.freemem())
    console.timeEnd('method2')
    ws.end('finish')
  })
}
method2()


// function demo() {
//   const rs = fs.createReadStream('./write-stream.txt');
//   const ws = fs.createWriteStream('./write-stream23.txt');
//   rs.pipe(ws)
// }
// demo()

http.listen(12306, ()=> {
  console.log('starrt')
})