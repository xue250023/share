// case 1

// setTimeout(() => {
// console.log('setTimeout')
// }, 1000)

// console.log('sync')


// case 2

// setTimeout(() => {
// console.log('setTimeout')
// }, 1)

// setImmediate(() => {
// console.log('setImmediate')
// })

// case 3

// const fs = require('fs')
// fs.readFile('./index.js', 'utf-8', (err, data) => {
//   setTimeout(() => {
//     console.log('setTimeout')
//   }, 1)

//   setImmediate(() => {
//     console.log('setImmediate')
//   })
// })

// case 4

// let i = 0;
// console.time('test')
// function test() {
//   i++
//   if(i < 1000) {
//     setImmediate(test, 0)
//   } else {
//     console.timeEnd('test')
//   }
// }
// test()



setImmediate(() => {
  console.log(1)
})

process.nextTick(() => {
  console.log(2);
  process.nextTick(() => {
    console.log(3)
  })
})

console.log(4)

Promise.resolve().then(() => {
  console.log(5)
  process.nextTick(() => {
    console.log(6)
  })
})