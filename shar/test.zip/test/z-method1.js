const fs = require('fs')
const path = require('path')
const os = require('os')
const http = require('http').createServer()



const filename = path.resolve(__dirname, './write-stream-test.txt')

async function method1() {
  console.time('method1')
  const fromfile = path.resolve(__dirname, './write-stream.txt');
  const tofile = path.resolve(__dirname, './write-stream22.txt');
  const tmp = await fs.promises.readFile(fromfile);
  await fs.promises.writeFile(tofile, tmp)
  console.timeEnd('method1')
  console.log(os.freemem())
}
method1()

console.log(process.pid)

http.listen(12305, ()=> {
  console.log('starrt')
})