const fs = require('fs')
const path = require('path')

const filename = path.resolve(__dirname, './write-stream-test.txt')

const ws = fs.createWriteStream(filename, {
  encoding: 'utf-8',
  highWaterMark: 2
})
// let flag;
// flag = ws.write('a')
// console.log(flag)
// flag = ws.write('a')
// console.log(flag)
// flag = ws.write('a')
// console.log(flag)
// flag = ws.write('a')
// console.log(flag)







// for(let i = 0; i < 2**20*10; i++){
//   ws.write('a')
// }





let i = 0;
function write() {
  let flag;
  flag = ws.write('a');
  while(i < 2**20*10 && flag) {
    flag = ws.write('a')
    i++;
  }
}
write()

ws.on('drain', () => {
  write()
})