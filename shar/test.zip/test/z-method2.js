const fs = require('fs')
const path = require('path')
const os = require('os')
const http = require('http').createServer()



const filename = path.resolve(__dirname, './write-stream-test.txt')


console.log(process.pid)
function method2() {
  console.time('method2')
  console.log(os.freemem())
  const rs = fs.createReadStream('./write-stream.txt');
  const ws = fs.createWriteStream('./write-stream23.txt');
  rs.on('data', (chunk) => {
    flag = ws.write(chunk)
    if(!flag) {
      rs.pause()
    }
  })

  ws.on('drain', () => {
    rs.resume()
  })

  rs.on('end', () => {
    console.log(os.freemem())
    console.timeEnd('method2')
    ws.end('finish')
  })
}
method2()
http.listen(12307, ()=> {
  console.log('starrt')
})