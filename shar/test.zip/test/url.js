const URL = require('url')

const a_url = 'https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&ch=&tn=baiduerr&bar=&wd=baidu';

const url = new URL.URL(a_url);

console.log(url)
console.log(url.searchParams.has('f'))


const obj = {
  href: 'https://www.baidu.com/s?ie=utf-8&f=8&rsv_bp=1&ch=&tn=baiduerr&bar=&wd=baidu',
  origin: 'https://www.baidu.com',
  protocol: 'https:',
  username: '',
  password: '',
  host: 'www.baidu.com',
  hostname: 'www.baidu.com',
  port: '',
  pathname: '/s',
  search: '?ie=utf-8&f=8&rsv_bp=1&ch=&tn=baiduerr&bar=&wd=baidu'
}

console.log(URL.format(obj))