<template>
<!--src/components/Loading/index.wxml-->
<div class="loading" :style="'width: ' + size + '; height: ' + size">
  <div :class="'loading__spinner loading__spinner--' + type" :style="'color: ' + color + ';'">
    <div v-for="(item, index) in 12" :key="index" v-if="type === 'spinner'" class="loading__dot"></div>
  </div>
</div>
</template>

<script>
export default {
  data() {
    return {};
  },

  components: {},
  props: {
    size: {
      type: String,
      default: '30px'
    },
    type: {
      type: String,
      default: 'spinner'
    },
    color: {
      type: String,
      default: '#c9c9c9'
    }
  },
  methods: {}
};</script>
<style lang="less">
@import "./index.less";
</style>