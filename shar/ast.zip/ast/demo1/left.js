<view
  class="loading"
  style="width: {{ size }}; height: {{ size }}"
>
  <view
    class="loading__spinner loading__spinner--{{ type }}"
    style="color: {{ color }};"
  >
    <view
      wx:if="{{ type === 'spinner' }}"
      wx:for="item in 12"
      wx:key="{{ index }}"
      class="loading__dot"
    />
  </view>
</view>


// src/components/Loading/index.js
Component({
  /**
   * Component properties
   */
  properties: {
    size: {
      type: String,
      value: '30px'
    },
    type: {
      type: String,
      value: 'spinner'
    },
    color: {
      type: String,
      value: '#c9c9c9'
    }
  },
  /**
   * Component initial data
   */
  data: {

  },

  /**
   * Component methods
   */
  methods: {

  }
})
