const fs = require('fs')
const csstree = require('css-tree')
const path = require('path')
const css = fs.readFileSync(path.resolve(__dirname, './index.css')).toString()

const ast = csstree.parse(css)
console.log(ast)
const ingnore = ['border-radius']
csstree.walk(ast, function(node) {
  if (node.type === 'Declaration') {
    if (ingnore.includes(node.property)) {
      return
    }
    node.value.children.forEach(dim => {
      if (dim.type === 'Dimension' && dim.unit === 'px') {
        dim.unit = 'vw'
        dim.value = ((+dim.value) / (750 / 100)).toFixed(4)
      }
    })
  }
})

fs.writeFileSync(path.resolve(__dirname, './_index.css'), csstree.generate(ast))