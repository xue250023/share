const parser = require('posthtml-parser')
const fs = require('fs')
const path = require('path')
const html = fs.readFileSync(path.resolve(__dirname, './index.html')).toString()

const ast = parser(html)
console.log(ast)
function traversePostTemplate(ast, callback) {
  ast.forEach(node => {
    callback(node, ast)
    node.content && traversePostTemplate(node.content, callback)
  })
  return ast
}

function postToString(ast) {
  let str = ''
  ast.forEach(item => {
    if (item.tag) {
      str += '<' + item.tag
      if (item.attrs) {
        Object.keys(item.attrs).forEach(attr => {
          let value = item.attrs[attr]
          if (value == "") {
            str += ` ${attr}`
          } else {
            str += ` ${attr}="${item.attrs[attr]}"`
          }
        })
      }
      str += '>'
      if (item.content && item.content.length) {
        str += postToString(item.content)
      }
      str += `</${item.tag}>`
    } else {
      if (typeof item === 'object') {
        str += ''
      } else {
        str += item
      }
    }
  })
  return str
}
const tagMap = {
  'div': 'view',
  'span': 'text'
}
const attrsMap = {
  'v-if': {
    key: 'wx:if',
    value: (val) => {
      return `{{${val}}}`
    }
  },
  'v-else': {
    key: 'wx:else'
  },
  'v-for': {
    key: 'wx:for',
    value: (val) => {
      const forarr = val.split(/\s+/)
      return `{{${forarr[2]}}}`
    }
  },
  'v-on:click': {
    key: 'bindtap',
    value: (val) => {
      return val
    }
  }
}
const newAst = traversePostTemplate(ast, (node) => {
  if (node.tag) {
    const attrs = node.attrs || {}
    // 替换标签
    if (tagMap[node.tag]) {
      node.tag = tagMap[node.tag]
    }
    // 替换属性
    for (let [key, val] of Object.entries(attrs)) {
      if (attrsMap[key]) {
        const valObj = attrsMap[key]
        attrs[valObj.key ? valObj.key : key] = valObj.value ? valObj.value(val) : val
        key !== valObj.key && delete attrs[key]
      }
    }
  }
})
fs.writeFileSync(path.resolve(__dirname, './_index.html'), postToString(newAst))