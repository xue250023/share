export default {
  c: 1
}