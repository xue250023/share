export default {
  b: 1
}