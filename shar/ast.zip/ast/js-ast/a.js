import b from './b.js'
import c from './c.js'
console.log(b)
const a = {
  b,
  c
}
export default a