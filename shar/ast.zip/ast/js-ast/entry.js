import a from './a.js'
console.log(a)