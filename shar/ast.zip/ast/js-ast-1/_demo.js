const _this = void 0;

let obj = {
  func: function () {
    console.log(_this);
  }
};
let obj1 = {
  func: function () {
    console.log(_this);
  }
};

let func = function () {
  console.log(_this);
};

function fun() {
  console.log(this);
}