let obj = {
  func: () => {
    console.log(this)
  }
}

let obj1 = {
  func: () => {
    console.log(this)
  }
}

let func = () => {
  console.log(this)
}
function fun() {
  console.log(this)
}