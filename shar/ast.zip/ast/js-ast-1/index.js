const traverse = require('@babel/traverse').default
const parser = require('@babel/parser')
const generator = require('@babel/generator').default
const t = require('@babel/types')
const template = require('@babel/template').default
const fs = require('fs')
const path = require('path')
const code = fs.readFileSync(path.resolve(__dirname, './demo.js')).toString()

function JavascriptParser(code, callback) {
  const ast = parser.parse(code, {
    sourceType: "module",
    plugins: [
      'typescript',
      'classProperties',
      'asyncGenerators',
      'decorators-legacy',
    ]
  })
  console.log(ast)
  traverse(ast, {
    enter(path) {
      callback(path)
    }
  })
  return generator(ast, {}, code).code
}
let program
let constThis = false
const newCode = JavascriptParser(code, (path) => {
  if (t.isProgram(path.node)) {
    program = path
  }
  if (t.isIdentifier(path.node) && path.node.name === '_this') {
    constThis = true
  }
  if(t.isArrowFunctionExpression(path.node)) {
    const node = path.node
    node.type = 'FunctionExpression'
    path.traverse({
      enter(path) {
        if (t.isThisExpression(path.node)) {
          path.replaceWith(t.identifier('_this'))
          if (!constThis) {
            program.node.body.unshift(template.ast`const _this = void 0;`)
          }
        }
      }
    })
  }
})

fs.writeFileSync(path.resolve(__dirname, './_demo.js'), newCode)
